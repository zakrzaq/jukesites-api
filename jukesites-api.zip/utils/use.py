def use_envs():
    import os
    from dotenv import load_dotenv
    load_dotenv()
    # global ev
    # ev = dict(os.environ)
